/** Automatically generated file. DO NOT MODIFY */
package com.dongnaoedu.qqvoicerchange;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}