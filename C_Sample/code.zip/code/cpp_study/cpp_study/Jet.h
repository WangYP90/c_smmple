#pragma once

#include "Plane.h"

//ֱ���ɻ�
class Jet : public Plane{
	virtual void fly();
	virtual void land();
};