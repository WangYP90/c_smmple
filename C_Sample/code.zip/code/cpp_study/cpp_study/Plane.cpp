#include "Plane.h"

#include <iostream>
using namespace std;

void Plane::fly(){
	cout << "���" << endl;
}

void Plane::land(){
	cout << "��½" << endl;
}