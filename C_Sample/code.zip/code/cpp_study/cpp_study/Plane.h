#pragma once

//��ͨ�ɻ�
class Plane{
public:
	virtual void fly();
	virtual void land();
};